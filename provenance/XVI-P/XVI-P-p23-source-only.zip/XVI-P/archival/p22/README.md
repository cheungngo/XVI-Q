# archival/p22 -- the p22 release (evanescent M2/CT, runtime d guard; superseded by p23)

p22 was released on 2026-10-10. Source-only zip `XVI-P-p22-source-only.zip`: sha256
ade2fa5c2dac6614c41ae38dc97d7c485975015a134650734d466ea6ffdef76f, 194 files. Source tree
1bc6edff6ca0788bb0fee4e8bf259bf8a0c80791f6dd08be77f79e56b492a50c. Reference values reference_values_p22.json
0d556339.... Author rebuild passed (662/662 equal; report ef505542...).

INDEPENDENT REBUILD OF p22: PASSED, with findings (no mismatches). Report
`reproducibility/independent_rebuild_report_p22.json` (archived copy byte-identical, sha256
023e5b83b1eba35d7c27b75841f446cb259580808410dbfb00253ea0122b15f3), bound to tree 1bc6edff... / zip ade2fa5c....
SAME-BOX caveat: it ran on the same machine as the author build, NOT on a second machine. p23 records
independent_rebuild_passed_p22 = true; the p23 tree does NOT inherit it.

Reviewer findings and their p23 disposition:
- runtime_guard_bypass_poly_algebra (low) -> p23 contract revision: polynomial-domain refusal and Dummy-only internal
  renames of d; live probe in release_p23 (rem/resultant/compose/div/prem/Poly.shift/Poly.rem/Matrix renames).
- p22_gate_does_not_check_EV_values (low) -> release_p23 checks rho, the E2/SE coefficients and the summed h.h
  counterterm coefficients against pinned values AND the archived p22 certificate.
- renormalized_scope (info): the title line now carries the two-point / QdS qualifier.
- pins_live_in_unpinned_conventions, earlier_layer_gates_accept_p22_cert_edits, ev_decoupling_structural,
  rho_single_equation_test, not_recomputed (info): recorded; no action (by design or informational).
